package com.example.myapplication.ui.dashboard

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.databinding.FragmentDashboardBinding

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val dashboardViewModel =
            ViewModelProvider(this)[DashboardViewModel::class.java]

        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val sharedPreferences = requireContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

        binding.edit1.setText(sharedPreferences.getString("edit1_text", ""))
        binding.edit2.setText(sharedPreferences.getString("edit2_text", ""))

        binding.button.setOnClickListener {
            val text1 = binding.edit1.text.toString()
            val text2 = binding.edit2.text.toString()

            with(sharedPreferences.edit()) {
                putString("edit1_text", text1)
                putString("edit2_text", text2)
                apply()
            }

            Toast.makeText(requireContext(), "saved", Toast.LENGTH_SHORT).show()
        }

        val textView: TextView = binding.textDashboard
        dashboardViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
